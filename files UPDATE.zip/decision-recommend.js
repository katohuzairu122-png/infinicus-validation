// functions/api/business/decision-recommend.js — INFINICUS v3 (Block 7)
// POST /api/business/decision-recommend
// Body: { email, businessId, decisionLabel, baselineSpec, baselineResult, modifiedSpec, modifiedResult }
//   baselineResult/modifiedResult — REAL simulate() outputs the client
//   already computed for "current path" vs "the proposed decision"
// Requires: INFINICUS_DB (D1) binding. ANTHROPIC_API_KEY optional —
// see the honest-fallback note below.
//
// Expected Outcome/Risk here are REAL — the literal numeric diff
// between two actual simulation runs (computeProjection applied to
// each, then subtracted), never invented by the AI. The AI's only job
// is writing a narrative EXPLANATION of numbers that already exist,
// matching the exact discipline v3's own real simulate.js prompt
// already states outright: "Never invent statistics."
//
// Reuses the same real, server-side Anthropic pattern as simulate.js
// (Block established in the original v3 repo, not new here) — the
// same env.ANTHROPIC_API_KEY, the same honest fallback when the key
// isn't configured or the call fails: the real numbers are returned
// regardless, with ai_narrative explicitly null, never a fabricated
// explanation standing in for a real one.

import { computeProjection } from '../../_shared/projection.js';
import { makeRateLimiter, getClientIP } from '../../_shared/rateLimit.js';

// Same real limit as v3's own simulate.js — this endpoint has the
// same real cost profile (a live Anthropic call when configured).
const checkRate = makeRateLimiter(10, 60 * 60 * 1000);

function uuid() {
  return crypto.randomUUID();
}

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type': 'application/json',
};

export async function onRequestOptions() {
  return new Response(null, { status: 204, headers: CORS });
}

function buildNarrativePrompt(decisionLabel, baseline, modified, diff) {
  return `You are explaining a real business decision to a founder, grounded strictly in the numbers below. Never invent statistics or numbers not given here.

DECISION BEING CONSIDERED: ${decisionLabel}

BASELINE (current path, 90-day simulated projection):
  Total Revenue: $${Math.round(baseline.totalRevenue).toLocaleString()}
  Total Profit: $${Math.round(baseline.totalProfit).toLocaleString()}
  Final Cash: $${Math.round(baseline.finalCash).toLocaleString()}
  Runway: ${baseline.solventThroughHorizon ? 'Solvent through 90 days' : `Day ${baseline.projectedRunwayDays}`}

MODIFIED (with the proposed decision applied):
  Total Revenue: $${Math.round(modified.totalRevenue).toLocaleString()}
  Total Profit: $${Math.round(modified.totalProfit).toLocaleString()}
  Final Cash: $${Math.round(modified.finalCash).toLocaleString()}
  Runway: ${modified.solventThroughHorizon ? 'Solvent through 90 days' : `Day ${modified.projectedRunwayDays}`}

REAL DIFFERENCE (modified minus baseline):
  Revenue change: $${Math.round(diff.revenueChange).toLocaleString()}
  Profit change: $${Math.round(diff.profitChange).toLocaleString()}
  Final cash change: $${Math.round(diff.finalCashChange).toLocaleString()}

In 2-3 sentences, explain what this difference means for the founder in plain language. Reference the actual numbers above. Do not add any statistic, percentage, or claim not directly computable from what's given.`;
}

export const _resetRateLimiterForTesting = () => checkRate._resetForTesting();

export async function onRequestPost({ request, env }) {
  const ip = getClientIP(request);
  if (!checkRate(ip)) {
    return new Response(JSON.stringify({ ok: false, error: 'Rate limit exceeded. Try again in an hour.' }), { status: 429, headers: CORS });
  }

  let body = {};
  try { body = await request.json(); } catch (e) {}

  const email = (body.email || '').trim().toLowerCase();
  const businessId = (body.businessId || '').trim();
  const decisionLabel = (body.decisionLabel || '').trim();
  const { baselineSpec, baselineResult, modifiedSpec, modifiedResult } = body;

  if (!email || !businessId || !decisionLabel) {
    return new Response(JSON.stringify({ ok: false, error: 'email, businessId, and decisionLabel required.' }), { status: 400, headers: CORS });
  }
  if (!baselineResult?.days?.length || !modifiedResult?.days?.length) {
    return new Response(JSON.stringify({ ok: false, error: 'baselineResult.days and modifiedResult.days are required — real simulation outputs, not fabricated.' }), { status: 400, headers: CORS });
  }
  if (!baselineSpec || !modifiedSpec) {
    return new Response(JSON.stringify({ ok: false, error: 'baselineSpec and modifiedSpec are required.' }), { status: 400, headers: CORS });
  }

  const db = env.INFINICUS_DB;
  if (!db) {
    return new Response(JSON.stringify({ ok: false, error: 'Database not configured. Contact support.' }), { status: 500, headers: CORS });
  }

  const business = await db.prepare('SELECT id FROM businesses WHERE id = ? AND owner_email = ?').bind(businessId, email).first();
  if (!business) {
    return new Response(JSON.stringify({ ok: false, error: 'Business not found for this account.' }), { status: 404, headers: CORS });
  }

  const baseline = computeProjection(baselineResult, baselineSpec);
  const modified = computeProjection(modifiedResult, modifiedSpec);

  // The real Expected Outcome — literal arithmetic on two real
  // simulation runs, not an AI estimate.
  const diff = {
    revenueChange: modified.totalRevenue - baseline.totalRevenue,
    profitChange: modified.totalProfit - baseline.totalProfit,
    finalCashChange: modified.finalCash - baseline.finalCash,
    runwayChange: (modified.projectedRunwayDays === null || baseline.projectedRunwayDays === null)
      ? null // honest null if either scenario never goes negative — a numeric "change" between a real day and "never" isn't a meaningful number
      : modified.projectedRunwayDays - baseline.projectedRunwayDays,
  };

  let aiNarrative = null;
  const apiKey = env.ANTHROPIC_API_KEY;
  if (apiKey) {
    try {
      const AnthropicModule = await import('@anthropic-ai/sdk');
      const Anthropic = AnthropicModule.default;
      const client = new Anthropic({ apiKey });
      const message = await client.messages.create({
        model: 'claude-haiku-4-5-20251001',
        max_tokens: 300,
        messages: [{ role: 'user', content: buildNarrativePrompt(decisionLabel, baseline, modified, diff) }],
      });
      aiNarrative = message.content[0]?.text || null;
    } catch (e) {
      // Honest fallback — the real numbers above still stand on their
      // own without a narrative. Never fabricate an explanation.
      aiNarrative = null;
    }
  }

  const id = uuid();
  const createdAt = Date.now();
  await db.prepare(
    'INSERT INTO decisions (id, business_id, decision_label, baseline_projection, modified_projection, expected_outcome, ai_narrative, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
  ).bind(id, businessId, decisionLabel, JSON.stringify(baseline), JSON.stringify(modified), JSON.stringify(diff), aiNarrative, createdAt).run();

  return new Response(JSON.stringify({
    ok: true,
    id,
    decisionLabel,
    baseline,
    modified,
    expectedOutcome: diff,
    aiNarrative,
    createdAt,
  }), { status: 200, headers: CORS });
}
