// functions/_shared/rateLimit.js — INFINICUS v3 (Block 9 review finding)
//
// Found genuinely missing across all 21 new backend endpoints during
// review — v3's own real simulate.js already has per-IP rate limiting
// (10/hour), but nothing built in this whole effort reused that
// pattern. Extracted here so it's applied consistently, not
// reinvented per file.
//
// Real, stated limitation: this is in-memory (a Map), so it resets on
// every cold start — exactly the same limitation v3's own real
// simulate.js already has and accepts. Not pretending this is more
// robust than it actually is.
//
// THRESHOLDS ARE A REAL PRODUCT DECISION, not a verified standard —
// same as v3's own chosen "10/hour" for its AI-costly endpoint. Each
// caller picks its own limit/window based on its real cost/abuse
// profile; there is no single correct universal number.

export function makeRateLimiter(limit, windowMs) {
  const rateMap = new Map();
  const checkRate = function (ip) {
    const now = Date.now();
    const entry = rateMap.get(ip) || { count: 0, reset: now + windowMs };
    if (now > entry.reset) { entry.count = 0; entry.reset = now + windowMs; }
    entry.count++;
    rateMap.set(ip, entry);
    return entry.count <= limit;
  };
  // Testing-only — production rate limiting is deliberately persistent
  // across requests (that's the whole point); this exists purely so
  // test suites with many calls to the same rate-limited endpoint
  // don't interfere with each other via a real Node require() cache
  // sharing one limiter instance across the whole test file.
  checkRate._resetForTesting = () => rateMap.clear();
  return checkRate;
}

export function getClientIP(request) {
  if (!request || !request.headers || typeof request.headers.get !== 'function') return 'unknown';
  return request.headers.get('CF-Connecting-IP')
    || request.headers.get('x-forwarded-for')?.split(',')[0]
    || 'unknown';
}
