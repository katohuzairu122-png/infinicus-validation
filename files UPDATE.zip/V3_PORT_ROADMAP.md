# INFINICUS — Porting v5's Business Intelligence Layer into v3

## Instructions for Claude Code

This document is a handoff, not a spec written in isolation — everything
under "Verified facts" was confirmed by directly reading real source files
over the course of a long session; everything under "Unverified — confirm
first" is a real, named gap, not guessed around. Follow the same discipline
throughout this port: **read and verify before building, test after every
change, never fabricate a working feature that isn't genuinely working.**

---

## 0. The actual goal

v3 (live at `infini-cus.com`) is a mature, working 90-day business
simulator — real accounts, real Monte Carlo engine, real AI analysis, real
production infrastructure. v5 (built in a separate, parallel effort) added
an entire second layer v3 doesn't have at all: **tracking a real, ongoing
business after the simulation**, not just evaluating a one-time idea.

The goal is not to replace v3, and not to make v5 the host. It's to port
v5's business-tracking layer **into v3's own real architecture**, matching
v3's actual code conventions, not v5's.

---

## 1. Verified facts about v3 (confirmed by direct source reading)

### Frontend
- Single-file `index.html` (~6,100 lines), no separate CSS file found
- Client-side code contains a magic-link auth flow
  (`requestMagicLink()`/`checkMagicLink()`, calling `/api/auth/request`
  and `/api/auth/verify`) — **confirmed dead/non-functional**, see
  Section 2. The real, live auth is password-based.
- Client-side engine: `simulate()` / `monteCarlo()` / `simulateLong()` — 13
  industries, 90-day horizon, currency conversion, seasonality curves,
  location-based cost adjustment, 4 strategy modes, a 25-entry random event
  pool, a 52-entry alternative-business database
- `account.html`, `landing.html`, `legal.html`, `pitch_deck.html` — separate
  real pages

### Backend (Cloudflare Pages Functions, confirmed real and complete)
- `functions/api/simulate.js` — server-side AI narrative generation
  (Anthropic, real API key via `ANTHROPIC_API_KEY`), NOT the simulation
  engine itself — the engine runs client-side, this only writes the report
- `functions/api/waitlist.js` — waitlist capture to Cloudflare KV +
  Resend welcome/owner emails
- `functions/api/nurture.js` / `nurture-batch.js` — Day 3/7 email follow-ups,
  batch version scans KV, cron-triggered externally (Cloudflare Pages has
  no native cron)
- `functions/api/parse-idea.js` — Cloudflare Workers AI vision
  (`llama-3.2-11b-vision-instruct`), image-to-idea extraction
- `functions/api/send-email.js` — results-report email delivery
- `functions/api/feedback.js` — feedback capture to KV + Resend

### Infrastructure
- Cloudflare Pages + Pages Functions (confirmed via `wrangler.toml`)
- Cloudflare KV: `INFINICUS_USERS`, `INFINICUS_WAITLIST` namespaces
- `supabase.js` exists in one snapshot of the repo but is **explicitly
  labeled a stub** (`Status: STUB`, placeholder credentials, commented-out
  Stripe webhook) — do not assume it's active without checking the current
  live environment variables first

---

## 2. Resolved — real auth backend confirmed, magic-link confirmed dead

**Real, complete, working system found at `functions/api/auth/`:**
- `login.js` and `register.js` both read/write `INFINICUS_USERS` KV under
  `user:{email}`, both use identical PBKDF2 parameters (100,000 iterations,
  SHA-256) and the same salt-generation pattern — fully consistent with
  each other, confirmed by reading both files directly, not inferred from
  one alone.
- `register.js`: validates email format and 8+ char password, rejects
  duplicate emails (409), stores `{email, passwordHash, salt, plan:'free',
  simCount:0, createdAt}`.
- `login.js`: verifies password against the stored hash, returns a safe
  user object (`email, plan, simCount, createdAt` — no hash/salt).
- `change-password.js` exists in the same folder, not yet read in detail,
  but its presence is consistent with this being the complete, real
  system (not a partial/abandoned one).

**Confirmed dead code, not a live feature:** `index.html`'s
`requestMagicLink()` / `checkMagicLink()` call `/api/auth/request` and
`/api/auth/verify` — endpoints that don't exist anywhere in this repo.
With both `login.js` and `register.js` now confirmed as a complete,
internally consistent, working password-based system, the magic-link
client code is leftover from an earlier design that was replaced. It is
unreachable/non-functional in production as written.

**What this means for the port:**
- Build v3's new account-dependent features (business tracking, Digital
  Twin, etc.) against the **real, live system**: `POST /api/auth/login`,
  `POST /api/auth/register`, `POST /api/auth/change-password`, backed by
  `INFINICUS_USERS` KV, identified by `user:{email}` keys.
- **Do not port or build anything assuming magic-link auth is live** — it
  isn't, regardless of what the client-side code appears to do.
- Recommend removing or fixing `requestMagicLink()`/`checkMagicLink()` and
  their associated UI (the "check your inbox" flow, `auth-step-sent`,
  etc.) as a first, small, low-risk cleanup step — confirm with the
  project owner before deleting anything, in case there's a reason it's
  still there that isn't visible from the code alone.
- User identity for the new business-tracking layer should key off
  `email` (matching how `login.js`/`register.js` already identify users),
  not a Firestore-style `uid` — v3 has no Firestore usage anywhere in its
  confirmed real code.

---

## Progress (updated as blocks complete — see project files for the real code)

- ✅ Test harness + baseline verification of the real engine and auth (Block 1)
- ✅ 3.1 Business data layer — D1, event-sourced (Block 2)
- ✅ 3.2 Operations modules — sales/inventory/finance/customers/team (Block 3)
- ✅ 3.3 BI Engine + KPI Dashboard (Block 4)
- ✅ 3.4 Digital Twin — real TTL caching, verified genuinely stale-aware (Block 5)
- ✅ 3.6 Decision Intelligence + Decision Memory — real Expected Outcome from genuine simulation diffs (Block 7), real windowed actual-outcome tracking with no fabricated accuracy score (Block 8)
- ✅ 3.7 Multi-business support — genuinely verified, not assumed: real tests confirm one owner's multiple businesses stay correctly isolated across summaries, the Digital Twin cache, and decision history
- ✅ 3.8 Onboarding tutorial / plan display / share links — all three confirmed ALREADY BUILT in v3's real code, just architected differently than v5's versions:
  - Onboarding: a real, complete `TUT` object (spotlight overlay, auto-launch for first-timers, persisted state, manual re-trigger)
  - Plan display: a real, complete plan-hero UI in `account.html`, wired to the same `plan` field `login.js` already returns
  - Share links: a real, complete `shareLink()` — architecturally different from v5's server-stored links (stateless, results base64-encoded directly into the URL, no backend storage needed) but genuinely working for its purpose
  - No new code written for this section — building a competing implementation would have duplicated something that already works, inconsistent with the stated principle of preferring v3's own conventions over importing v5's wholesale

**Roadmap Section 3 (the actual port) is now fully complete — 3.1 through 3.8, all verified against real v3 code, none assumed.**

## Full Review Findings (post-Block-9)

A comprehensive pass across all 29 backend files, not just re-confirming
green tests. Three real, previously-unverified things found and fixed:

1. **`_shared/*.js` routing exposure, genuinely unverified until checked.**
   Assumed since Block 6 that Cloudflare Pages excludes underscore-prefixed
   paths from Function routing — this was never actually confirmed, and
   official docs describe file-based routing across the whole `/functions`
   tree with `_routes.json` as the real, documented exclusion mechanism.
   Real risk was low (no secrets in those files, no `onRequest*` handler
   for Cloudflare to invoke even if routed) but the assumption itself was
   wrong to leave unverified. Fixed with a real `_routes.json`.

2. **10 of 29 files touched the database with zero error handling.**
   A genuine D1 failure would have propagated as an unhandled exception
   rather than a clean, honest response. Fixed across all 10, each
   verified with a real broken-D1 mock that genuinely throws — not just
   asserting a try/catch exists in the source.

3. **A real, subtle bug the fix itself surfaced:** `twin.js`'s refresh
   path collapsed "business not found" and "a real database error
   occurred" into the same 404 status. A genuine cache-write failure
   would have been misreported as 404, not 500. Fixed, and specifically
   tested — including proving `whatif-spec.js` correctly propagates that
   same fix transitively, since it delegates to twin.js rather than
   touching D1 directly.

Also found: `ALTER TABLE ADD COLUMN` in `schema.sql` is not idempotent
(no `IF NOT EXISTS` equivalent) — documented directly in the file rather
than engineered around, since it's a one-time setup script.

**65/65 tests passing. `index.html`, `account.html`, and every other
real, pre-existing v3 file confirmed untouched throughout all 9 blocks.**

## Second Review Pass — Security & Test Infrastructure

Different angle from the first review: checked injection risk and rate
limiting, neither previously audited.

- **SQL injection: confirmed clean.** Every query uses `?` placeholders
  with `.bind()` — including the one place genuine user input (`type`
  in `events.js`) flows into a query. 36 `prepare()` calls, 36 `bind()`
  calls, no template-literal SQL construction anywhere.

- **Rate limiting: found completely absent** across all 21 new
  endpoints, despite v3's own real `simulate.js` already having a
  working per-IP pattern. Added a shared helper reusing that exact
  algorithm, applied to `decision-recommend.js` first (the one endpoint
  with a real cost profile — a live Anthropic call). **The other 20
  endpoints still need the same treatment before real deployment** —
  this is a genuine, standing gap, not resolved by one endpoint.

- **A real bug the rate-limiter fix itself exposed:** a test asserting
  cross-business decision isolation never checked whether its own setup
  call actually succeeded. Investigation revealed the test harness
  wasn't genuinely sequential — tests started their async bodies
  immediately without awaiting the previous test, so a shared,
  `require()`-cached rate limiter could be exhausted out of file order.
  Fixed at the root (the harness is now genuinely sequential via
  internal promise-chaining, zero changes needed to any of the 65+
  existing test call sites) rather than patched around with fragile,
  order-dependent resets.

- **Making the harness correctly sequential surfaced a second, real
  bug**, independent of rate limiting: two `Date.now()` calls in rapid
  succession can land in the same millisecond, making a windowed
  financial query's `created_at >= sinceTimestamp` boundary ambiguous.
  Fixed by adding genuine timing separation in the one test that
  needed it — not by weakening the production `>=` semantic, which is
  correct for real usage where actions are naturally separated by more
  than a millisecond.

**65/65 passing after both fixes.**

**Still open, not forgotten:**
- Dead magic-link code in `index.html` — needs your confirmation before removal
- Platform-wide missing session token — every endpoint trusts a client-provided email; a real fix, bigger than any single block, not yet addressed

## 3. What v5 built that v3 doesn't have (the actual port list)

In dependency order — each depends on the ones above it existing first.

### 3.1 Real business data layer
Event-sourced tracking: `business.sale.created`, `business.expense.recorded`,
`business.inventory.updated`, `business.customer.activity`,
`business.employee.logged`. v5 stored these in Firestore; **for v3, decide
storage explicitly rather than default to Firestore** — v3 has no Firestore
usage anywhere in its confirmed real code. Cloudflare KV, D1, or Supabase
(if reactivated) are the realistic options given v3's actual stack. Pick
one deliberately and document why.

### 3.2 Operations modules (5)
Sales summary, inventory summary, customer profiles (LTV, retention,
churn), finance summary (revenue/expense/cashflow), team summary
(roster, revenue-per-labor-hour). Each is a read/aggregate over 3.1's
event stream — build 3.1 first.

### 3.3 BI Engine + KPI Dashboard
Aggregates 3.2's five summaries, trend detection, benchmark comparison
against v3's own real industry data (already exists — reuse `PROFILES`,
don't duplicate).

### 3.4 Digital Twin
A cached, periodically-refreshed snapshot of a real business's current
state (financial/customer/operational/market behavior), built from 3.1-3.3.

### 3.5 Simulation Intelligence (what-if)
Maps Digital Twin state → v3's own real `simulate()`/`monteCarlo()` input
spec, runs it, diffs the result against current state. **Reuse v3's actual
engine unmodified** — do not build a second simulation engine.

### 3.6 Decision Intelligence + Decision Memory
AI-suggested decisions with Expected Outcome/Risk computed from real
simulation diffs (two what-if runs, with/without the decision) — never
AI-invented numbers. Decision Memory tracks user choice + actual outcome
over time, feeding accuracy context back into future recommendations.

### 3.7 Multi-business support
Letting one account track more than one real business.

### 3.8 Supporting pieces (smaller, can interleave)
- Onboarding tutorial (spotlight tour)
- Plan/tier display (v3 may already have something close to this — check
  `account.html` and the pricing references in `pitch_deck.html` before
  building a parallel system)
- Read-only share links

---

## 4. Real mistakes made building v5's version of this — avoid repeating them

These are not hypothetical risks. Each one actually happened and was caught
mid-build:

1. **A ported engine silently dropped a whole subsystem (random events)**
   because it wasn't in the function signature being copied from. When
   porting/reusing v3's real engine code, diff the ported version against
   the actual source line-by-line — don't assume a function's visible
   behavior is its complete behavior.

2. **A duplicate, independently-built implementation of the same feature
   existed in the codebase simultaneously**, undetected until a naming-
   collision check surfaced it. It fabricated placeholder data for fields
   the real engine doesn't track. Before adding a new subsystem, grep for
   whether something with the same name/purpose already exists.

3. **A Firestore/KV write only ever went to a subcollection, never to the
   parent document itself**, making collection-level listing silently
   return nothing in production despite every mocked test passing. If
   using KV or a DB, verify a *direct* read of whatever you just wrote
   actually returns it — don't trust that a nested write implies the
   parent path exists.

4. **`package.json`'s `"type": "module"` broke an entire CommonJS test
   suite** the moment it was added, because Node resolves module type from
   the nearest `package.json`. If v3's test tooling (if any exists) is
   CommonJS, adding ESM-related config for a new Cloudflare Function can
   break it silently — check this before adding the field.

5. **A security-rules/permissions gap** (if using Firestore: an entire
   collection path had no rule at all) passed every test against mocks
   while being invisibly blocked by the real backend's default-deny.
   Mocked tests proving a feature "works" don't prove it works against
   real infrastructure — this whole v5 effort was built and tested
   entirely against mocks and has never been deployed for real either,
   so this risk transfers directly.

6. **Fields the engine genuinely doesn't compute (competitor data, social/
   reputation data) were, in the discarded duplicate, fabricated as
   plausible-looking placeholder numbers** instead of left honestly null.
   Whenever a real data source doesn't cover something, return null/absent
   and let the UI show that plainly — never synthesize a number that looks
   real but isn't derived from anything.

---

## 5. Working discipline for this whole effort

- Read the real, current file before editing it — don't assume prior
  snapshots (including this document) are still accurate
- After every change: run whatever test suite exists; if none exists for
  a piece of v3, that's worth flagging rather than silently proceeding
  untested
- State assumptions explicitly in commit messages/comments when the real
  source (e.g., the auth backend) couldn't be found
- Prefer v3's own existing conventions (its function style, its CORS
  headers, its KV usage patterns) over importing v5's patterns wholesale —
  the goal is v3 gaining capability while staying recognizably v3, not a
  v5 transplant
- Get explicit confirmation before any change that touches real user data,
  real auth, or anything already live and working for existing users
