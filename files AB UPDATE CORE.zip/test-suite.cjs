// INFINICUS v3 — Test Suite
// Block 1: baseline verification only. No new v3 features yet — this
// proves the harness works and documents the REAL, current behavior
// of what's already live, so every future change has something to
// regress against.

const { test, section, resetPoint, assert, assertEqual, loadEngine, makeMockKV, makeMockD1, makeBrokenMockD1, run } = require('./test-harness.cjs');
const fs = require('fs');
const path = require('path');

section('Engine harness loads correctly');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

let engine;
test('The real index.html engine loads without error, and its core functions/data are present', () => {
  engine = loadEngine();
  assert(typeof engine.simulate === 'function');
  assert(typeof engine.monteCarlo === 'function');
  assert(typeof engine.simulateLong === 'function');
  assert(typeof engine.PROFILES === 'object');
  assertEqual(engine.SIM_DAYS, 90);
});

section('Real engine behavior (documenting what already works, not changing it)');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

test('PROFILES contains the real 13 industries', () => {
  const keys = Object.keys(engine.PROFILES);
  assertEqual(keys.length, 13);
  ['food', 'retail', 'saas', 'service', 'fitness', 'agency', 'health', 'edtech', 'marketplace', 'events', 'fintech', 'realestate', 'logistics']
    .forEach(k => assert(keys.includes(k), `Missing industry: ${k}`));
});

test('simulate() runs a real 90-day simulation and returns real day-by-day data', () => {
  const result = engine.simulate({ industry: 'food', capital: 8000, price: 6, mktBud: 300, team: 2 });
  assert(Array.isArray(result.days));
  assertEqual(result.days.length, 90);
  assert(Array.isArray(result.events));
  assert(typeof result.days[0].cash === 'number');
});

test('monteCarlo() runs real percentile-based batch simulation', () => {
  const result = engine.monteCarlo({ industry: 'saas', capital: 15000, price: 49, mktBud: 800, team: 3 });
  assert(typeof result.survivalRate === 'number');
  assert(result.survivalRate >= 0 && result.survivalRate <= 1);
  assert(typeof result.p50 === 'number');
});

section('Real auth functions (login.js / register.js) — behavioral verification via mock KV');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

test('register.js: valid email + 8+ char password creates a real user record in KV', async () => {
  const { onRequestPost } = require('./functions/api/auth/register.js');
  const kv = makeMockKV();
  const request = { json: async () => ({ email: 'Test@Example.com', password: 'longenoughpw' }) };
  const response = await onRequestPost({ request, env: { INFINICUS_USERS: kv } });
  const body = await response.json();
  assertEqual(response.status, 200);
  assert(body.ok);
  assertEqual(body.email, 'test@example.com', 'Email must be normalized to lowercase');
  const stored = JSON.parse(await kv.get('user:test@example.com'));
  assert(stored.passwordHash && stored.salt, 'Real password hash and salt must be stored');
  assert(stored.passwordHash !== 'longenoughpw', 'Password must never be stored in plain text');
});

test('register.js: rejects a password under 8 characters before ever touching KV', async () => {
  const { onRequestPost } = require('./functions/api/auth/register.js');
  const kv = makeMockKV();
  const request = { json: async () => ({ email: 'short@example.com', password: 'short' }) };
  const response = await onRequestPost({ request, env: { INFINICUS_USERS: kv } });
  const body = await response.json();
  assertEqual(response.status, 400);
  assertEqual(body.ok, false);
  assertEqual(await kv.get('user:short@example.com'), null, 'Nothing must be written to KV for a rejected registration');
});

test('register.js: rejects a duplicate email (409), does not overwrite the existing account', async () => {
  const { onRequestPost } = require('./functions/api/auth/register.js');
  const kv = makeMockKV();
  const req1 = { json: async () => ({ email: 'dup@example.com', password: 'firstpassword' }) };
  await onRequestPost({ request: req1, env: { INFINICUS_USERS: kv } });
  const firstStored = await kv.get('user:dup@example.com');

  const req2 = { json: async () => ({ email: 'dup@example.com', password: 'secondpassword' }) };
  const response = await onRequestPost({ request: req2, env: { INFINICUS_USERS: kv } });
  const body = await response.json();

  assertEqual(response.status, 409);
  assertEqual(body.ok, false);
  assertEqual(await kv.get('user:dup@example.com'), firstStored, 'The original account must be untouched');
});

test('login.js: correct password authenticates and returns a safe user object (no hash/salt exposed)', async () => {
  const { onRequestPost: register } = require('./functions/api/auth/register.js');
  const { onRequestPost: login } = require('./functions/api/auth/login.js');
  const kv = makeMockKV();
  await register({ request: { json: async () => ({ email: 'login@example.com', password: 'correctpassword' }) }, env: { INFINICUS_USERS: kv } });

  const response = await login({ request: { json: async () => ({ email: 'login@example.com', password: 'correctpassword' }) }, env: { INFINICUS_USERS: kv } });
  const body = await response.json();

  assertEqual(response.status, 200);
  assert(body.ok);
  assertEqual(body.email, 'login@example.com');
  assertEqual(body.passwordHash, undefined, 'Response must never include the password hash');
  assertEqual(body.salt, undefined, 'Response must never include the salt');
});

test('login.js: incorrect password is rejected (401), correct password for a DIFFERENT account is rejected too', async () => {
  const { onRequestPost: register } = require('./functions/api/auth/register.js');
  const { onRequestPost: login } = require('./functions/api/auth/login.js');
  const kv = makeMockKV();
  await register({ request: { json: async () => ({ email: 'victim@example.com', password: 'realpassword123' }) }, env: { INFINICUS_USERS: kv } });
  await register({ request: { json: async () => ({ email: 'other@example.com', password: 'differentpassword' }) }, env: { INFINICUS_USERS: kv } });

  const wrongPw = await login({ request: { json: async () => ({ email: 'victim@example.com', password: 'wrongguess' }) }, env: { INFINICUS_USERS: kv } });
  assertEqual(wrongPw.status, 401);

  const crossAccount = await login({ request: { json: async () => ({ email: 'victim@example.com', password: 'differentpassword' }) }, env: { INFINICUS_USERS: kv } });
  assertEqual(crossAccount.status, 401, 'A correct password for a DIFFERENT account must not authenticate this one — real salted-hash isolation, not just any-valid-password');
});

test('login.js: an email with no account returns 404, not a generic error or false positive', async () => {
  const { onRequestPost } = require('./functions/api/auth/login.js');
  const kv = makeMockKV();
  const response = await onRequestPost({ request: { json: async () => ({ email: 'nobody@example.com', password: 'anything' }) }, env: { INFINICUS_USERS: kv } });
  assertEqual(response.status, 404);
});

section('Real business data layer (Block 2)');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

test('business/create.js: creates a real business row in D1, tied to the owner email', async () => {
  const { onRequestPost } = require('./functions/api/business/create.js');
  const db = makeMockD1();
  const request = { json: async () => ({ email: 'Owner@Example.com', name: 'Test Cafe', industry: 'food' }) };
  const response = await onRequestPost({ request, env: { INFINICUS_DB: db } });
  const body = await response.json();

  assertEqual(response.status, 200);
  assert(body.ok);
  assert(body.id, 'A real business id must be returned');
  assertEqual(db._tables.businesses.length, 1);
  assertEqual(db._tables.businesses[0].owner_email, 'owner@example.com', 'Email must be normalized to lowercase, matching auth');
});

test('business/create.js: rejects missing name/industry before touching the database', async () => {
  const { onRequestPost } = require('./functions/api/business/create.js');
  const db = makeMockD1();
  const response = await onRequestPost({ request: { json: async () => ({ email: 'x@example.com', name: '', industry: 'food' }) }, env: { INFINICUS_DB: db } });
  assertEqual(response.status, 400);
  assertEqual(db._tables.businesses.length, 0);
});

test('business/create.js: rejects an industry that is not one of the real 13 valid keys — a real gap found and fixed before Block 6 could depend on it', async () => {
  const { onRequestPost } = require('./functions/api/business/create.js');
  const db = makeMockD1();
  const response = await onRequestPost({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'not_a_real_industry' }) }, env: { INFINICUS_DB: db } });
  assertEqual(response.status, 400);
  assertEqual(db._tables.businesses.length, 0);
});

test('business/event.js: records a real sale event, tied to the correct business', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const db = makeMockD1();

  const createRes = await createBiz({ request: { json: async () => ({ email: 'seller@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const eventRes = await recordEvent({
    request: { json: async () => ({ email: 'seller@example.com', businessId, type: 'sale', data: { amount: 49.99, item: 'Widget' } }) },
    env: { INFINICUS_DB: db },
  });
  const eventBody = await eventRes.json();

  assertEqual(eventRes.status, 200);
  assert(eventBody.ok);
  assertEqual(db._tables.business_events.length, 1);
  assertEqual(JSON.parse(db._tables.business_events[0].data).amount, 49.99);
});

test('business/event.js: rejects an invalid event type before writing anything', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'not_a_real_type', data: {} }) }, env: { INFINICUS_DB: db } });
  assertEqual(response.status, 400);
  assertEqual(db._tables.business_events.length, 0);
});

test('business/event.js: rejects recording an event on a business owned by a DIFFERENT email — real ownership isolation, not just existence checking', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'realowner@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await recordEvent({
    request: { json: async () => ({ email: 'attacker@example.com', businessId, type: 'sale', data: { amount: 100, item: 'x' } }) },
    env: { INFINICUS_DB: db },
  });
  assertEqual(response.status, 404, 'A different email claiming an existing businessId must be rejected, not silently allowed');
  assertEqual(db._tables.business_events.length, 0);
});

test('business/list.js: returns only the requesting emails businesses, real isolation between accounts', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: listBiz } = require('./functions/api/business/list.js');
  const db = makeMockD1();
  await createBiz({ request: { json: async () => ({ email: 'alice@example.com', name: 'Alices Shop', industry: 'food' }) }, env: { INFINICUS_DB: db } });
  await createBiz({ request: { json: async () => ({ email: 'bob@example.com', name: 'Bobs Shop', industry: 'saas' }) }, env: { INFINICUS_DB: db } });

  const response = await listBiz({ request: { url: 'https://x.test/api/business/list?email=alice@example.com' }, env: { INFINICUS_DB: db } });
  const body = await response.json();

  assertEqual(body.businesses.length, 1);
  assertEqual(body.businesses[0].name, 'Alices Shop');
});

test('business/events.js: lists real events for a business, correctly filtered by type when requested', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: listEvents } = require('./functions/api/business/events.js');
  const db = makeMockD1();

  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 10, item: 'a' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'expense', data: { amount: 5, category: 'supplies' } }) }, env: { INFINICUS_DB: db } });

  const allRes = await listEvents({ request: { url: `https://x.test/api/business/events?email=x@example.com&businessId=${businessId}` } , env: { INFINICUS_DB: db } });
  const allBody = await allRes.json();
  assertEqual(allBody.events.length, 2);

  const saleRes = await listEvents({ request: { url: `https://x.test/api/business/events?email=x@example.com&businessId=${businessId}&type=sale` }, env: { INFINICUS_DB: db } });
  const saleBody = await saleRes.json();
  assertEqual(saleBody.events.length, 1);
  assertEqual(saleBody.events[0].data.amount, 10);
});

test('business/events.js: rejects listing events for a business owned by a different email', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: listEvents } = require('./functions/api/business/events.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'owner@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await listEvents({ request: { url: `https://x.test/api/business/events?email=attacker@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  assertEqual(response.status, 404);
});

section('Operations modules (Block 3)');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

test('summary/sales.js: a business with zero sales reports honest zeros/nulls, not fabricated data', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: salesSummary } = require('./functions/api/business/summary/sales.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await salesSummary({ request: { url: `https://x.test/api/business/summary/sales?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();

  assertEqual(body.totalRevenue, 0);
  assertEqual(body.saleCount, 0);
  assertEqual(body.avgOrderValue, null, 'Average of zero sales must be honest null, not 0 or NaN');
  assertEqual(body.trend, null);
});

test('summary/sales.js: computes real revenue, AOV, and top items from actual recorded sales', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: salesSummary } = require('./functions/api/business/summary/sales.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 100, item: 'Widget' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 50, item: 'Gadget' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 150, item: 'Widget' } }) }, env: { INFINICUS_DB: db } });

  const response = await salesSummary({ request: { url: `https://x.test/api/business/summary/sales?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();

  assertEqual(body.totalRevenue, 300);
  assertEqual(body.saleCount, 3);
  assertEqual(body.avgOrderValue, 100);
  assertEqual(body.topItems[0].item, 'Widget');
  assertEqual(body.topItems[0].revenue, 250, 'Widget appears twice (100+150), must be summed correctly, not just counted');
});

test('summary/sales.js: a single sale reports honest null trend, not a fabricated 0% or 100%', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: salesSummary } = require('./functions/api/business/summary/sales.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 42, item: 'Solo' } }) }, env: { INFINICUS_DB: db } });

  const response = await salesSummary({ request: { url: `https://x.test/api/business/summary/sales?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();
  assertEqual(body.trend, null, 'A single data point has no meaningful trend — must not fabricate one');
});

test('summary/sales.js: rejects a business owned by a different email, same isolation as event.js', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: salesSummary } = require('./functions/api/business/summary/sales.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'owner@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await salesSummary({ request: { url: `https://x.test/api/business/summary/sales?email=attacker@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  assertEqual(response.status, 404);
});

test('summary/inventory.js: signed quantity convention — restocks and consumption correctly net into a real current level', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: invSummary } = require('./functions/api/business/summary/inventory.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'inventory', data: { item: 'Widget', quantity: 100 } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'inventory', data: { item: 'Widget', quantity: -30 } }) }, env: { INFINICUS_DB: db } });

  const response = await invSummary({ request: { url: `https://x.test/api/business/summary/inventory?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();
  assertEqual(body.items[0].currentLevel, 70, '100 restocked - 30 consumed = 70');
});

test('summary/inventory.js: daysUntilStockout is honest null with fewer than 2 consumption events, real when there are enough to compute a rate', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: invSummary } = require('./functions/api/business/summary/inventory.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'inventory', data: { item: 'Solo', quantity: 50 } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'inventory', data: { item: 'Solo', quantity: -5 } }) }, env: { INFINICUS_DB: db } });
  const oneEventRes = await invSummary({ request: { url: `https://x.test/api/business/summary/inventory?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const oneEventBody = await oneEventRes.json();
  assertEqual(oneEventBody.items.find(i => i.item === 'Solo').daysUntilStockout, null, 'A single consumption event gives no meaningful rate');
});

test('summary/finance.js: real revenue minus real expenses, correctly categorized', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: financeSummary } = require('./functions/api/business/summary/finance.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 500, item: 'x' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'expense', data: { amount: 100, category: 'supplies' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'expense', data: { amount: 50, category: 'rent' } }) }, env: { INFINICUS_DB: db } });

  const response = await financeSummary({ request: { url: `https://x.test/api/business/summary/finance?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();
  assertEqual(body.revenue, 500);
  assertEqual(body.totalExpenses, 150);
  assertEqual(body.netProfit, 350);
  assertEqual(body.expensesByCategory.supplies, 100);
  assertEqual(body.expensesByCategory.rent, 50);
});

test('summary/customers.js: LTV honest null for customers without linked sales, real LTV for those with it — never fabricated', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: custSummary } = require('./functions/api/business/summary/customers.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'customer', data: { action: 'signup', customerId: 'cust_1' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'customer', data: { action: 'signup', customerId: 'cust_2' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 75, item: 'x', customerId: 'cust_1' } }) }, env: { INFINICUS_DB: db } });
  // cust_2 has no linked sale — must report null LTV, not 0 or fabricated

  const response = await custSummary({ request: { url: `https://x.test/api/business/summary/customers?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();

  assertEqual(body.totalCustomers, 2);
  assertEqual(body.customersWithLinkedRevenue, 1);
  const cust1 = body.customers.find(c => c.customerId === 'cust_1');
  const cust2 = body.customers.find(c => c.customerId === 'cust_2');
  assertEqual(cust1.ltv, 75);
  assertEqual(cust2.ltv, null, 'A customer with no linked sale must report honest null LTV, never 0 or a fabricated value');
});

test('summary/team.js: real hours and revenue-per-labor-hour, honest null with zero hours logged', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: teamSummary } = require('./functions/api/business/summary/team.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const zeroHoursRes = await teamSummary({ request: { url: `https://x.test/api/business/summary/team?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const zeroHoursBody = await zeroHoursRes.json();
  assertEqual(zeroHoursBody.revenuePerLaborHour, null, 'Zero hours logged must report honest null, not a division-by-zero crash or fabricated rate');

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'employee', data: { hours: 10, action: 'shift' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 200, item: 'x' } }) }, env: { INFINICUS_DB: db } });

  const response = await teamSummary({ request: { url: `https://x.test/api/business/summary/team?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();
  assertEqual(body.totalHours, 10);
  assertEqual(body.revenuePerLaborHour, 20, '200 revenue / 10 hours = 20');
});

section('BI Engine / KPI Dashboard (Block 4)');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

test('summary/dashboard.js: aggregates all 5 real summaries correctly, reusing their actual computation', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: dashboard } = require('./functions/api/business/summary/dashboard.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Full Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 500, item: 'Widget' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'expense', data: { amount: 200, category: 'rent' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'inventory', data: { item: 'Widget', quantity: 50 } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'employee', data: { hours: 20, action: 'shift' } }) }, env: { INFINICUS_DB: db } });

  const response = await dashboard({ request: { url: `https://x.test/api/business/summary/dashboard?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();

  assertEqual(response.status, 200);
  assert(body.ok);
  assertEqual(body.business.name, 'Full Shop');
  assertEqual(body.sales.totalRevenue, 500, 'Must reuse sales.js real computation, not a duplicate/inconsistent one');
  assertEqual(body.finance.netProfit, 300);
  assertEqual(body.inventory.items[0].currentLevel, 50);
  assertEqual(body.team.totalHours, 20);
  assertEqual(body.profitMargin, 0.6, '300 net profit / 500 revenue = 0.6');
});

test('summary/dashboard.js: honest null profitMargin when there is zero revenue, never a fabricated percentage', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: dashboard } = require('./functions/api/business/summary/dashboard.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'New Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await dashboard({ request: { url: `https://x.test/api/business/summary/dashboard?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();
  assertEqual(body.profitMargin, null);
});

test('summary/dashboard.js: rejects a business owned by a different email before ever calling the 5 sub-summaries', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: dashboard } = require('./functions/api/business/summary/dashboard.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'owner@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await dashboard({ request: { url: `https://x.test/api/business/summary/dashboard?email=attacker@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  assertEqual(response.status, 404);
});

section('Digital Twin (Block 5)');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

test('twin.js: first GET with no cache triggers a real refresh and genuinely caches the result', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: getTwin } = require('./functions/api/business/twin.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 100, item: 'x' } }) }, env: { INFINICUS_DB: db } });

  assertEqual(db._tables.business_twin.length, 0, 'No cache should exist before the first fetch');
  const response = await getTwin({ request: { url: `https://x.test/api/business/twin?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();

  assertEqual(body.sales.totalRevenue, 100);
  assertEqual(body.stale, false);
  assertEqual(db._tables.business_twin.length, 1, 'A cache row must genuinely be written after the first refresh');
});

test('twin.js: a second GET within the TTL returns the cached snapshot, NOT freshly recomputed data — proven by adding new events between reads', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: getTwin } = require('./functions/api/business/twin.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 100, item: 'x' } }) }, env: { INFINICUS_DB: db } });

  await getTwin({ request: { url: `https://x.test/api/business/twin?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });

  // Real new data recorded AFTER the cache was populated — a naive
  // "always recompute" implementation would pick this up; genuine
  // caching must not.
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 9999, item: 'should not appear yet' } }) }, env: { INFINICUS_DB: db } });

  const secondResponse = await getTwin({ request: { url: `https://x.test/api/business/twin?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const secondBody = await secondResponse.json();
  assertEqual(secondBody.sales.totalRevenue, 100, 'Must still show the CACHED value (100), not the new real total (10099) — proves the cache is genuinely used, not silently bypassed');
  assertEqual(db._tables.business_twin.length, 1, 'Still only one cache row — no duplicate/second insert on a cache hit');
});

test('twin.js: a stale cache (older than TTL) triggers a real refresh with current data', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: getTwin } = require('./functions/api/business/twin.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 100, item: 'x' } }) }, env: { INFINICUS_DB: db } });
  await getTwin({ request: { url: `https://x.test/api/business/twin?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });

  // Simulate real staleness by backdating the cache's refreshed_at
  // beyond the TTL — the only practical way to test a 5-minute TTL
  // without a real 5-minute wait.
  db._tables.business_twin[0].refreshed_at = Date.now() - (10 * 60 * 1000);
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 50, item: 'y' } }) }, env: { INFINICUS_DB: db } });

  const response = await getTwin({ request: { url: `https://x.test/api/business/twin?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();
  assertEqual(body.sales.totalRevenue, 150, 'A stale cache must trigger a genuine refresh picking up the new event');
});

test('twin.js: POST force-refresh bypasses the cache even when it is still fresh', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: getTwin, onRequestPost: postTwin } = require('./functions/api/business/twin.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 100, item: 'x' } }) }, env: { INFINICUS_DB: db } });
  await getTwin({ request: { url: `https://x.test/api/business/twin?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 25, item: 'z' } }) }, env: { INFINICUS_DB: db } });

  const response = await postTwin({ request: { json: async () => ({ email: 'x@example.com', businessId }), url: `https://x.test/api/business/twin` }, env: { INFINICUS_DB: db } });
  const body = await response.json();
  assertEqual(body.sales.totalRevenue, 125, 'Force refresh must pick up the new data even though the cache was still within TTL');
});

test('twin.js: rejects a business owned by a different email, same isolation as everything else', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: getTwin } = require('./functions/api/business/twin.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'owner@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await getTwin({ request: { url: `https://x.test/api/business/twin?email=attacker@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  assertEqual(response.status, 404);
});

section('Simulation Intelligence (Block 6)');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

test('whatif-spec.js: rejects missing capital/team before ever touching the Twin — genuinely not derivable, must be explicit', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: whatifSpec } = require('./functions/api/business/whatif-spec.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const noCapital = await whatifSpec({ request: { url: `https://x.test/api/business/whatif-spec?email=x@example.com&businessId=${businessId}&team=3` }, env: { INFINICUS_DB: db } });
  assertEqual(noCapital.status, 400);

  const noTeam = await whatifSpec({ request: { url: `https://x.test/api/business/whatif-spec?email=x@example.com&businessId=${businessId}&capital=10000` }, env: { INFINICUS_DB: db } });
  assertEqual(noTeam.status, 400);
});

test('whatif-spec.js: derives price from real sales.avgOrderValue and mktBud from real marketing expenses when available', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: whatifSpec } = require('./functions/api/business/whatif-spec.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 80, item: 'x' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'expense', data: { amount: 300, category: 'marketing' } }) }, env: { INFINICUS_DB: db } });

  const response = await whatifSpec({ request: { url: `https://x.test/api/business/whatif-spec?email=x@example.com&businessId=${businessId}&capital=10000&team=3` }, env: { INFINICUS_DB: db } });
  const body = await response.json();

  assertEqual(body.spec.industry, 'retail');
  assertEqual(body.spec.price, 80, 'Must derive price from the real avgOrderValue, not a fabricated default');
  assertEqual(body.spec.mktBud, 300, 'Must derive mktBud from the real marketing expense category');
  assertEqual(body.derivedFrom.price, 'sales.avgOrderValue');
});

test('whatif-spec.js: honest 0 mktBud (not fabricated) when no marketing expense category exists, and requires an explicit price when no sales exist yet', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: whatifSpec } = require('./functions/api/business/whatif-spec.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'New Shop', industry: 'saas' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const noPriceRes = await whatifSpec({ request: { url: `https://x.test/api/business/whatif-spec?email=x@example.com&businessId=${businessId}&capital=10000&team=2` }, env: { INFINICUS_DB: db } });
  assertEqual(noPriceRes.status, 400, 'No sales recorded yet and no price override — must error honestly, not fabricate a price');

  const withPriceRes = await whatifSpec({ request: { url: `https://x.test/api/business/whatif-spec?email=x@example.com&businessId=${businessId}&capital=10000&team=2&price=49` }, env: { INFINICUS_DB: db } });
  const body = await withPriceRes.json();
  assertEqual(body.spec.mktBud, 0, 'No marketing expense recorded — honest 0, not skipped or fabricated');
  assertEqual(body.derivedFrom.price, 'override');
});

test('whatif-spec.js: explicit overrides take precedence over derived values, for real what-if experimentation', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: whatifSpec } = require('./functions/api/business/whatif-spec.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 80, item: 'x' } }) }, env: { INFINICUS_DB: db } });

  const response = await whatifSpec({ request: { url: `https://x.test/api/business/whatif-spec?email=x@example.com&businessId=${businessId}&capital=10000&team=3&price=120` }, env: { INFINICUS_DB: db } });
  const body = await response.json();
  assertEqual(body.spec.price, 120, 'Override (120) must win over the derived value (80) — this is what makes it a genuine what-if');
});

test('whatif-diff.js: computes a real, honest projection summary from an actual simulation result', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: whatifDiff } = require('./functions/api/business/whatif-diff.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  // A real-shaped, minimal simulate() result — solvent throughout
  const days = [];
  let cash = 10000;
  for (let d = 1; d <= 90; d++) { cash += 50; days.push({ d, rev: 100, cost: 50, profit: 50, cash }); }

  const response = await whatifDiff({
    request: { json: async () => ({ email: 'x@example.com', businessId, spec: { capital: 10000, industry: 'retail', price: 80, mktBud: 0, team: 2 }, simulationResult: { days, events: [] } }) },
    env: { INFINICUS_DB: db },
  });
  const body = await response.json();

  assertEqual(body.projection.horizonDays, 90);
  assertEqual(body.projection.startingCapital, 10000);
  assertEqual(body.projection.totalRevenue, 9000, '100 rev/day * 90 days');
  assertEqual(body.projection.finalCash, 10000 + 50 * 90);
  assertEqual(body.projection.solventThroughHorizon, true);
  assertEqual(body.projection.projectedRunwayDays, null, 'Solvent throughout — honest null runway, not a fabricated number');
});

test('whatif-diff.js: reports the real day cash goes negative, not a fabricated round number', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: whatifDiff } = require('./functions/api/business/whatif-diff.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const days = [];
  let cash = 500;
  for (let d = 1; d <= 90; d++) { cash -= 20; days.push({ d, rev: 10, cost: 30, profit: -20, cash }); }

  const response = await whatifDiff({
    request: { json: async () => ({ email: 'x@example.com', businessId, spec: { capital: 500, industry: 'retail', price: 10, mktBud: 0, team: 1 }, simulationResult: { days, events: [] } }) },
    env: { INFINICUS_DB: db },
  });
  const body = await response.json();
  assertEqual(body.projection.solventThroughHorizon, false);
  assertEqual(body.projection.projectedRunwayDays, 25, '500 / 20 per day = day 25 is the first day cash reaches <= 0');
});

test('whatif-diff.js: rejects a fabricated/empty simulationResult before computing anything', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: whatifDiff } = require('./functions/api/business/whatif-diff.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await whatifDiff({
    request: { json: async () => ({ email: 'x@example.com', businessId, spec: { capital: 1000 }, simulationResult: { days: [] } }) },
    env: { INFINICUS_DB: db },
  });
  assertEqual(response.status, 400);
});

test('whatif-diff.js: rejects a business owned by a different email', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: whatifDiff } = require('./functions/api/business/whatif-diff.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'owner@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await whatifDiff({
    request: { json: async () => ({ email: 'attacker@example.com', businessId, spec: { capital: 1000 }, simulationResult: { days: [{ d: 1, cash: 1000 }] } }) },
    env: { INFINICUS_DB: db },
  });
  assertEqual(response.status, 404);
});

section('Decision Intelligence (Block 7)');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

function makeSolventDays(startCash, dailyProfit, dailyRev) {
  const days = [];
  let cash = startCash;
  for (let d = 1; d <= 90; d++) { cash += dailyProfit; days.push({ d, rev: dailyRev, cost: dailyRev - dailyProfit, profit: dailyProfit, cash }); }
  return days;
}

test('decision-recommend.js: computes a real, honest Expected Outcome as literal arithmetic between two real simulation runs', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: decisionRecommend } = require('./functions/api/business/decision-recommend.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const baselineResult = { days: makeSolventDays(10000, 50, 100), events: [] };
  const modifiedResult = { days: makeSolventDays(10000, 80, 150), events: [] }; // "raise price" scenario, real higher revenue/profit

  const response = await decisionRecommend({
    request: { json: async () => ({
      email: 'x@example.com', businessId, decisionLabel: 'Raise price by 10%',
      baselineSpec: { capital: 10000 }, baselineResult,
      modifiedSpec: { capital: 10000 }, modifiedResult,
    }) },
    env: { INFINICUS_DB: db }, // no ANTHROPIC_API_KEY — exercises the honest no-key path
  });
  const body = await response.json();

  assertEqual(response.status, 200);
  assert(body.ok);
  assertEqual(body.baseline.totalRevenue, 9000, '100/day * 90 days');
  assertEqual(body.modified.totalRevenue, 13500, '150/day * 90 days');
  assertEqual(body.expectedOutcome.revenueChange, 4500, 'Must be literal modified minus baseline (13500-9000), not an AI estimate');
  assertEqual(body.expectedOutcome.profitChange, 2700, '(80-50)*90 = 2700');
  assertEqual(body.aiNarrative, null, 'No ANTHROPIC_API_KEY configured — must be honest null, never a fabricated explanation');
});

test('decision-recommend.js: the AI-call failure path (SDK unavailable in this environment) still returns real numbers, honest null narrative — not a crash', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: decisionRecommend } = require('./functions/api/business/decision-recommend.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const baselineResult = { days: makeSolventDays(5000, 20, 60), events: [] };
  const modifiedResult = { days: makeSolventDays(5000, 20, 60), events: [] };

  const response = await decisionRecommend({
    request: { json: async () => ({
      email: 'x@example.com', businessId, decisionLabel: 'No real change',
      baselineSpec: { capital: 5000 }, baselineResult,
      modifiedSpec: { capital: 5000 }, modifiedResult,
    }) },
    env: { INFINICUS_DB: db, ANTHROPIC_API_KEY: 'fake-key-for-testing' }, // key present, but SDK genuinely unavailable here — exercises the real try/catch fallback
  });
  const body = await response.json();

  assertEqual(response.status, 200, 'A failed AI call must not fail the whole request — the real numbers are still valid');
  assert(body.ok);
  assertEqual(body.aiNarrative, null);
  assertEqual(body.expectedOutcome.revenueChange, 0, 'Identical scenarios must show a real, honest zero difference');
});

test('decision-recommend.js: runwayChange is honest null when either scenario is solvent throughout — a real day number minus "never" is not a meaningful number', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: decisionRecommend } = require('./functions/api/business/decision-recommend.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const baselineResult = { days: makeSolventDays(5000, 20, 60), events: [] }; // solvent throughout
  const modifiedResult = { days: makeSolventDays(500, -20, 10), events: [] }; // goes negative

  const response = await decisionRecommend({
    request: { json: async () => ({
      email: 'x@example.com', businessId, decisionLabel: 'Risky change',
      baselineSpec: { capital: 5000 }, baselineResult,
      modifiedSpec: { capital: 500 }, modifiedResult,
    }) },
    env: { INFINICUS_DB: db },
  });
  const body = await response.json();
  assertEqual(body.expectedOutcome.runwayChange, null, 'Baseline never goes negative — comparing a real day to "never" is not a meaningful numeric diff');
});

test('decision-recommend.js: rejects fabricated/empty simulation results before computing anything', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: decisionRecommend } = require('./functions/api/business/decision-recommend.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await decisionRecommend({
    request: { json: async () => ({ email: 'x@example.com', businessId, decisionLabel: 'x', baselineSpec: {}, baselineResult: { days: [] }, modifiedSpec: {}, modifiedResult: { days: [] } }) },
    env: { INFINICUS_DB: db },
  });
  assertEqual(response.status, 400);
});

test('decision-recommend.js: the AI prompt explicitly instructs against inventing statistics, matching v3s own real simulate.js discipline', async () => {
  const src = fs.readFileSync(path.join(__dirname, 'functions/api/business/decision-recommend.js'), 'utf8');
  assert(src.includes('Never invent statistics') || src.includes('never invent'), 'The prompt must explicitly forbid fabricating numbers, matching the same real instruction already used in v3s own simulate.js');
});

test('decision-recommend.js: a real decision record is genuinely persisted to D1', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: decisionRecommend } = require('./functions/api/business/decision-recommend.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  await decisionRecommend({
    request: { json: async () => ({
      email: 'x@example.com', businessId, decisionLabel: 'Test decision',
      baselineSpec: { capital: 1000 }, baselineResult: { days: makeSolventDays(1000, 10, 20), events: [] },
      modifiedSpec: { capital: 1000 }, modifiedResult: { days: makeSolventDays(1000, 15, 25), events: [] },
    }) },
    env: { INFINICUS_DB: db },
  });
  assertEqual(db._tables.decisions.length, 1, 'A real decision record must be written, not just returned in the response');
  assertEqual(db._tables.decisions[0].decision_label, 'Test decision');
});

test('decision-recommend.js: rejects a business owned by a different email', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: decisionRecommend } = require('./functions/api/business/decision-recommend.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'owner@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await decisionRecommend({
    request: { json: async () => ({
      email: 'attacker@example.com', businessId, decisionLabel: 'x',
      baselineSpec: { capital: 1000 }, baselineResult: { days: makeSolventDays(1000, 10, 20), events: [] },
      modifiedSpec: { capital: 1000 }, modifiedResult: { days: makeSolventDays(1000, 10, 20), events: [] },
    }) },
    env: { INFINICUS_DB: db },
  });
  assertEqual(response.status, 404);
});

section('Decision Memory (Block 8)');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

test('decision-record-choice.js: records a real choice, rejects an invalid choice value before writing anything', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: decisionRecommend } = require('./functions/api/business/decision-recommend.js');
  const { onRequestPost: recordChoice } = require('./functions/api/business/decision-record-choice.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();
  const decRes = await decisionRecommend({
    request: { json: async () => ({
      email: 'x@example.com', businessId, decisionLabel: 'Raise price',
      baselineSpec: { capital: 1000 }, baselineResult: { days: makeSolventDays(1000, 10, 20), events: [] },
      modifiedSpec: { capital: 1000 }, modifiedResult: { days: makeSolventDays(1000, 15, 25), events: [] },
    }) }, env: { INFINICUS_DB: db },
  });
  const { id: decisionId } = await decRes.json();

  const badChoice = await recordChoice({ request: { json: async () => ({ email: 'x@example.com', businessId, decisionId, choice: 'maybe' }) }, env: { INFINICUS_DB: db } });
  assertEqual(badChoice.status, 400);
  assertEqual(db._tables.decisions[0].user_choice, null, 'Invalid choice must not be written');

  const goodChoice = await recordChoice({ request: { json: async () => ({ email: 'x@example.com', businessId, decisionId, choice: 'accepted', note: 'Trying it for a month' }) }, env: { INFINICUS_DB: db } });
  assertEqual(goodChoice.status, 200);
  assertEqual(db._tables.decisions[0].user_choice, 'accepted');
  assertEqual(db._tables.decisions[0].choice_note, 'Trying it for a month');
});

test('decision-record-choice.js: rejects a decision that does not belong to the given business', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordChoice } = require('./functions/api/business/decision-record-choice.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await recordChoice({ request: { json: async () => ({ email: 'x@example.com', businessId, decisionId: 'not-a-real-decision', choice: 'accepted' }) }, env: { INFINICUS_DB: db } });
  assertEqual(response.status, 404);
});

test('decision-record-outcome.js: reports real windowed revenue/profit since the decision, honestly excluding events from BEFORE the decision was made', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestPost: decisionRecommend } = require('./functions/api/business/decision-recommend.js');
  const { onRequestPost: recordOutcome } = require('./functions/api/business/decision-record-outcome.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  // Real sale BEFORE the decision — must NOT count toward the outcome
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 9999, item: 'pre-decision, must be excluded' } }) }, env: { INFINICUS_DB: db } });

  // Genuine delay to guarantee real timestamp separation — found during
  // review that rapid sequential Date.now() calls can land in the same
  // millisecond, which would make created_at >= sinceTimestamp ambiguous.
  // This is a real property of the test's own timing, not a weakening
  // of the production >= semantic, which is reasonable for real usage
  // where actions are naturally separated by more than 1ms.
  await new Promise(r => setTimeout(r, 5));

  const decRes = await decisionRecommend({
    request: { json: async () => ({
      email: 'x@example.com', businessId, decisionLabel: 'Raise price',
      baselineSpec: { capital: 1000 }, baselineResult: { days: makeSolventDays(1000, 10, 20), events: [] },
      modifiedSpec: { capital: 1000 }, modifiedResult: { days: makeSolventDays(1000, 15, 25), events: [] },
    }) }, env: { INFINICUS_DB: db },
  });
  const { id: decisionId } = await decRes.json();

  // Real sale AFTER the decision — must count
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 150, item: 'post-decision' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'expense', data: { amount: 50, category: 'supplies' } }) }, env: { INFINICUS_DB: db } });

  const response = await recordOutcome({ request: { json: async () => ({ email: 'x@example.com', businessId, decisionId }) }, env: { INFINICUS_DB: db } });
  const body = await response.json();

  assertEqual(body.actual.revenue, 150, 'Must be ONLY the post-decision sale (150), not the pre-decision 9999 too');
  assertEqual(body.actual.profit, 100, '150 revenue - 50 expense');
  assert(body.originalProjection.totalRevenue !== undefined, 'Must include the original projection for honest side-by-side comparison');
  assert(!('accuracyPercent' in body) && !('accuracy' in body), 'Must never compute a fabricated single accuracy score — there is no real counterfactual to score against');
});

test('decision-record-outcome.js: can be called more than once, updating with more real data each time — not a one-time lock', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestPost: decisionRecommend } = require('./functions/api/business/decision-recommend.js');
  const { onRequestPost: recordOutcome } = require('./functions/api/business/decision-record-outcome.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();
  const decRes = await decisionRecommend({
    request: { json: async () => ({
      email: 'x@example.com', businessId, decisionLabel: 'x',
      baselineSpec: { capital: 1000 }, baselineResult: { days: makeSolventDays(1000, 10, 20), events: [] },
      modifiedSpec: { capital: 1000 }, modifiedResult: { days: makeSolventDays(1000, 15, 25), events: [] },
    }) }, env: { INFINICUS_DB: db },
  });
  const { id: decisionId } = await decRes.json();

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 100, item: 'x' } }) }, env: { INFINICUS_DB: db } });
  const first = await recordOutcome({ request: { json: async () => ({ email: 'x@example.com', businessId, decisionId }) }, env: { INFINICUS_DB: db } });
  const firstBody = await first.json();
  assertEqual(firstBody.actual.revenue, 100);

  await recordEvent({ request: { json: async () => ({ email: 'x@example.com', businessId, type: 'sale', data: { amount: 50, item: 'y' } }) }, env: { INFINICUS_DB: db } });
  const second = await recordOutcome({ request: { json: async () => ({ email: 'x@example.com', businessId, decisionId }) }, env: { INFINICUS_DB: db } });
  const secondBody = await second.json();
  assertEqual(secondBody.actual.revenue, 150, 'Must reflect ALL real data since the decision, updated on each call — not frozen at the first recording');
});

test('decision-history.js: returns the full real lifecycle, with an honest null (not zero) for outcomes never recorded', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: decisionRecommend } = require('./functions/api/business/decision-recommend.js');
  const { onRequestPost: recordChoice } = require('./functions/api/business/decision-record-choice.js');
  const { onRequestGet: history } = require('./functions/api/business/decision-history.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();
  const decRes = await decisionRecommend({
    request: { json: async () => ({
      email: 'x@example.com', businessId, decisionLabel: 'Cut marketing spend',
      baselineSpec: { capital: 1000 }, baselineResult: { days: makeSolventDays(1000, 10, 20), events: [] },
      modifiedSpec: { capital: 1000 }, modifiedResult: { days: makeSolventDays(1000, 8, 18), events: [] },
    }) }, env: { INFINICUS_DB: db },
  });
  const { id: decisionId } = await decRes.json();
  await recordChoice({ request: { json: async () => ({ email: 'x@example.com', businessId, decisionId, choice: 'rejected', note: 'Too risky' }) }, env: { INFINICUS_DB: db } });

  const response = await history({ request: { url: `https://x.test/api/business/decision-history?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  const body = await response.json();

  assertEqual(body.decisions.length, 1);
  assertEqual(body.decisions[0].decisionLabel, 'Cut marketing spend');
  assertEqual(body.decisions[0].userChoice, 'rejected');
  assertEqual(body.decisions[0].choiceNote, 'Too risky');
  assertEqual(body.decisions[0].actualOutcome, null, 'Outcome never recorded — must be honest null, not a fabricated zero');
});

test('decision-history.js: rejects a business owned by a different email', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: history } = require('./functions/api/business/decision-history.js');
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'owner@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  const response = await history({ request: { url: `https://x.test/api/business/decision-history?email=attacker@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  assertEqual(response.status, 404);
});

section('Multi-business support verification (roadmap 3.7 — proven, not assumed)');
resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

test('One owner, two businesses: list.js returns both, correctly attributed', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: listBiz } = require('./functions/api/business/list.js');
  const db = makeMockD1();
  await createBiz({ request: { json: async () => ({ email: 'multi@example.com', name: 'Cafe', industry: 'food' }) }, env: { INFINICUS_DB: db } });
  await createBiz({ request: { json: async () => ({ email: 'multi@example.com', name: 'SaaS Co', industry: 'saas' }) }, env: { INFINICUS_DB: db } });

  const response = await listBiz({ request: { url: 'https://x.test/api/business/list?email=multi@example.com' }, env: { INFINICUS_DB: db } });
  const body = await response.json();
  assertEqual(body.businesses.length, 2);
  assert(body.businesses.some(b => b.name === 'Cafe' && b.industry === 'food'));
  assert(body.businesses.some(b => b.name === 'SaaS Co' && b.industry === 'saas'));
});

test('One owner, two businesses: real events recorded on Business A never appear in Business Bs sales summary', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: salesSummary } = require('./functions/api/business/summary/sales.js');
  const db = makeMockD1();
  const bizA = await (await createBiz({ request: { json: async () => ({ email: 'multi@example.com', name: 'Cafe', industry: 'food' }) }, env: { INFINICUS_DB: db } })).json();
  const bizB = await (await createBiz({ request: { json: async () => ({ email: 'multi@example.com', name: 'SaaS Co', industry: 'saas' }) }, env: { INFINICUS_DB: db } })).json();

  await recordEvent({ request: { json: async () => ({ email: 'multi@example.com', businessId: bizA.id, type: 'sale', data: { amount: 500, item: 'Coffee' } }) }, env: { INFINICUS_DB: db } });
  await recordEvent({ request: { json: async () => ({ email: 'multi@example.com', businessId: bizB.id, type: 'sale', data: { amount: 200, item: 'Subscription' } }) }, env: { INFINICUS_DB: db } });

  const aSummary = await (await salesSummary({ request: { url: `https://x.test/api/business/summary/sales?email=multi@example.com&businessId=${bizA.id}` }, env: { INFINICUS_DB: db } })).json();
  const bSummary = await (await salesSummary({ request: { url: `https://x.test/api/business/summary/sales?email=multi@example.com&businessId=${bizB.id}` }, env: { INFINICUS_DB: db } })).json();

  assertEqual(aSummary.totalRevenue, 500, 'Business A must show only its own real revenue, not combined with B');
  assertEqual(bSummary.totalRevenue, 200, 'Business B must show only its own real revenue, not combined with A');
});

test('One owner, two businesses: the Digital Twin cache is keyed per-business, not shared or cross-contaminated between them', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: recordEvent } = require('./functions/api/business/event.js');
  const { onRequestGet: getTwin } = require('./functions/api/business/twin.js');
  const db = makeMockD1();
  const bizA = await (await createBiz({ request: { json: async () => ({ email: 'multi@example.com', name: 'Cafe', industry: 'food' }) }, env: { INFINICUS_DB: db } })).json();
  const bizB = await (await createBiz({ request: { json: async () => ({ email: 'multi@example.com', name: 'SaaS Co', industry: 'saas' }) }, env: { INFINICUS_DB: db } })).json();

  await recordEvent({ request: { json: async () => ({ email: 'multi@example.com', businessId: bizA.id, type: 'sale', data: { amount: 777, item: 'x' } }) }, env: { INFINICUS_DB: db } });
  await getTwin({ request: { url: `https://x.test/api/business/twin?email=multi@example.com&businessId=${bizA.id}` }, env: { INFINICUS_DB: db } });

  const twinB = await (await getTwin({ request: { url: `https://x.test/api/business/twin?email=multi@example.com&businessId=${bizB.id}` }, env: { INFINICUS_DB: db } })).json();
  assertEqual(twinB.sales.totalRevenue, 0, 'Business Bs first twin fetch must show its own real (zero) revenue, never A\'s cached 777');
  assertEqual(db._tables.business_twin.length, 2, 'Two genuinely separate cache rows must exist, one per business, not one shared row');
});

test('One owner, two businesses: decision history for Business A never includes decisions made on Business B', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestPost: decisionRecommend, _resetRateLimiterForTesting } = require('./functions/api/business/decision-recommend.js');
  const { onRequestGet: history } = require('./functions/api/business/decision-history.js');
  _resetRateLimiterForTesting(); // avoid interference from other tests' calls to the same shared, cached module
  const db = makeMockD1();
  const bizA = await (await createBiz({ request: { json: async () => ({ email: 'multi@example.com', name: 'Cafe', industry: 'food' }) }, env: { INFINICUS_DB: db } })).json();
  const bizB = await (await createBiz({ request: { json: async () => ({ email: 'multi@example.com', name: 'SaaS Co', industry: 'saas' }) }, env: { INFINICUS_DB: db } })).json();

  const recRes = await decisionRecommend({
    request: { json: async () => ({
      email: 'multi@example.com', businessId: bizA.id, decisionLabel: 'Cafe decision',
      baselineSpec: { capital: 1000 }, baselineResult: { days: makeSolventDays(1000, 10, 20), events: [] },
      modifiedSpec: { capital: 1000 }, modifiedResult: { days: makeSolventDays(1000, 15, 25), events: [] },
    }) }, env: { INFINICUS_DB: db },
  });
  // The bug this fixes: this test previously never checked whether the
  // setup call actually succeeded. If it had silently failed (e.g. hit
  // a rate limit), Business B would ALSO show 0 decisions — a false
  // pass that proves nothing about real cross-business isolation.
  assertEqual(recRes.status, 200, 'Setup call must genuinely succeed, or this test proves nothing about real isolation');

  const bHistory = await (await history({ request: { url: `https://x.test/api/business/decision-history?email=multi@example.com&businessId=${bizB.id}` }, env: { INFINICUS_DB: db } })).json();
  assertEqual(bHistory.decisions.length, 0, 'Business B must show zero decisions — the Cafe decision must never leak across businesses owned by the same account');
});

section('Rate limiting rollout completed (found missing on 20 of 21 endpoints, now applied to all)');

test('decision-history.js: genuinely rate-limits after the real read-tier threshold (60/hour), not just accepting the code looks right', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: history, _resetRateLimiterForTesting } = require('./functions/api/business/decision-history.js');
  _resetRateLimiterForTesting();
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  let lastStatus;
  for (let i = 0; i < 61; i++) {
    const response = await history({ request: { url: `https://x.test/api/business/decision-history?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
    lastStatus = response.status;
  }
  assertEqual(lastStatus, 429, 'The 61st call within the same hour must genuinely be rejected, proving the limiter is real, not decorative');
});

test('twin.js: GET and POST are genuinely on SEPARATE rate-limit tiers — exhausting one does not affect the other', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: getTwin, onRequestPost: postTwin, _resetRateLimiterForTesting } = require('./functions/api/business/twin.js');
  _resetRateLimiterForTesting();
  const db = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: db } });
  const { id: businessId } = await createRes.json();

  // Exhaust POST's real, stricter limit (20/hour)
  let lastPostStatus;
  for (let i = 0; i < 21; i++) {
    const response = await postTwin({ request: { json: async () => ({ email: 'x@example.com', businessId }), url: 'https://x.test/api/business/twin' }, env: { INFINICUS_DB: db } });
    lastPostStatus = response.status;
  }
  assertEqual(lastPostStatus, 429, 'POST must genuinely be rate-limited after its own real 20-call threshold');

  // GET must be completely unaffected — separate tier, separate limiter instance
  const getResponse = await getTwin({ request: { url: `https://x.test/api/business/twin?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: db } });
  assertEqual(getResponse.status, 200, 'GET must be genuinely unaffected by POST exhausting its own separate limit — proving these are truly independent tiers, not a shared counter');
});


resetPoint(() => require('./functions/api/business/decision-record-outcome.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/decision-record-choice.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/event.js')._resetRateLimiterForTesting());
resetPoint(() => require('./functions/api/business/create.js')._resetRateLimiterForTesting());

test('list.js: a genuine D1 failure returns a clean 500, not an unhandled crash or raw stack trace', async () => {
  const { onRequestGet: listBiz } = require('./functions/api/business/list.js');
  const brokenDb = makeBrokenMockD1();
  const response = await listBiz({ request: { url: 'https://x.test/api/business/list?email=x@example.com' }, env: { INFINICUS_DB: brokenDb } });
  const body = await response.json();
  assertEqual(response.status, 500);
  assertEqual(body.ok, false);
  assert(!body.error.includes('Simulated D1'), 'The raw internal error message must never leak to the client — only the honest, generic message');
});

test('summary/sales.js: a genuine D1 failure returns a clean 500, computation never runs on undefined data', async () => {
  const { onRequestGet: salesSummary } = require('./functions/api/business/summary/sales.js');
  const brokenDb = makeBrokenMockD1();
  const response = await salesSummary({ request: { url: 'https://x.test/api/business/summary/sales?email=x@example.com&businessId=x' }, env: { INFINICUS_DB: brokenDb } });
  assertEqual(response.status, 500);
});

test('twin.js: a genuine D1 failure during the cache write is correctly reported as a real 500, not miscategorized as business-not-found (404) — the exact bug caught during review', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: getTwin } = require('./functions/api/business/twin.js');
  const goodDb = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: goodDb } });
  const { id: businessId } = await createRes.json();

  // Business genuinely exists (ownership check passes), but the cache
  // write itself fails — this must surface as 500, not the misleading
  // 404 the original, unreviewed code would have returned.
  const brokenWriteDb = {
    prepare(sql) {
      if (sql.includes('SELECT id FROM businesses')) return goodDb.prepare(sql);
      if (sql.includes('SELECT snapshot')) return { bind: () => ({ first: async () => null }) };
      return { bind: () => ({ run: async () => { throw new Error('Simulated cache write failure'); } }) };
    },
  };

  const response = await getTwin({ request: { url: `https://x.test/api/business/twin?email=x@example.com&businessId=${businessId}` }, env: { INFINICUS_DB: brokenWriteDb } });
  assertEqual(response.status, 500, 'A real DB failure must be 500, not the misleading 404 the pre-review code would have returned');
});

test('whatif-spec.js: correctly propagates a genuine underlying DB failure as 500 (transitively, via twin.js) — proven, not just asserted from reading the delegation', async () => {
  const { onRequestPost: createBiz } = require('./functions/api/business/create.js');
  const { onRequestGet: whatifSpec } = require('./functions/api/business/whatif-spec.js');
  const goodDb = makeMockD1();
  const createRes = await createBiz({ request: { json: async () => ({ email: 'x@example.com', name: 'Shop', industry: 'retail' }) }, env: { INFINICUS_DB: goodDb } });
  const { id: businessId } = await createRes.json();

  const brokenWriteDb = {
    prepare(sql) {
      if (sql.includes('SELECT id FROM businesses')) return goodDb.prepare(sql);
      if (sql.includes('SELECT snapshot')) return { bind: () => ({ first: async () => null }) };
      return { bind: () => ({ run: async () => { throw new Error('Simulated cache write failure'); } }) };
    },
  };

  const response = await whatifSpec({ request: { url: `https://x.test/api/business/whatif-spec?email=x@example.com&businessId=${businessId}&capital=10000&team=3&price=50` }, env: { INFINICUS_DB: brokenWriteDb } });
  assertEqual(response.status, 500, 'Must genuinely propagate the real 500 from the underlying twin fetch, not a fallback 404 or a crash');
});

(async () => { await run(); })();
