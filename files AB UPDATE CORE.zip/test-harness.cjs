// INFINICUS v3 — Test Harness
// Mirrors the approach used throughout the v5 build: load the REAL
// source, mock only what a Node environment genuinely lacks (DOM,
// Cloudflare's env/KV bindings), and verify actual behavior — never
// assume something works because the code looks right.
//
// Run: node test-harness.js

const fs = require('fs');
const path = require('path');

let passed = 0, failed = 0;
const failures = [];
let chain = Promise.resolve(); // internal serialization — see below

function test(name, fn) {
  // Found during review: tests were NOT actually sequential despite
  // running in file order — each test() call started its async body
  // immediately without awaiting the prior test, so tests genuinely
  // interleaved at the microtask level. This surfaced as a real,
  // confirmed bug: a shared rate-limiter instance (Node's require()
  // cache means all calls to the same endpoint across the whole file
  // share one limiter) could be exhausted by tests running out of
  // their apparent file order. Fixed at the root — chaining each
  // test onto the previous one's completion — rather than patching
  // around it with fragile, order-dependent resets scattered through
  // test-suite.cjs.
  chain = chain.then(async () => {
    try {
      const result = fn();
      if (result && typeof result.then === 'function') {
        await result;
      }
      passed++;
      console.log(`  \x1b[32m✓\x1b[0m ${name}`);
    } catch (err) {
      failed++;
      failures.push({ name, err });
      console.log(`  \x1b[31m✗\x1b[0m ${name}\n    ${err.message}`);
    }
  });
}

function section(title) {
  chain = chain.then(() => { console.log(`\n${title}`); });
}

function resetPoint(fn) {
  // Chains an arbitrary action (e.g. a rate-limiter reset) into the
  // SAME sequential flow as test(), so it executes at the correct
  // real position relative to actual test execution — not at file
  // top-level parse time, which is what a bare statement between
  // sections would do (the exact flaw already found and fixed once
  // in this file for test() itself).
  chain = chain.then(fn);
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'Assertion failed');
}
function assertEqual(actual, expected, msg) {
  if (actual !== expected) throw new Error(msg || `Expected ${JSON.stringify(expected)}, got ${JSON.stringify(actual)}`);
}

// ── Load the real index.html's inline scripts into a sandboxed global ──
function loadEngine() {
  const vm = require('vm');
  const html = fs.readFileSync(path.join(__dirname, 'index.html'), 'utf8');
  const scripts = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(m => m[1]);

  // v3 uses bare top-level `function`/`const` declarations (unlike v5,
  // which explicitly assigned everything to window.INFINICUS.x) — plain
  // eval() inside a CommonJS module doesn't attach those to a retrievable
  // scope, since eval() here runs inside Node's module-wrapper function,
  // not the true global scope. vm.createContext gives each declaration a
  // real global object to attach to, exactly like a real <script> tag in
  // a browser would.
  const fakeElement = () => ({
    style: {}, classList: { add() {}, remove() {}, toggle() {}, contains: () => false },
    setAttribute() {}, removeAttribute() {}, appendChild() {}, addEventListener() {},
    querySelector: () => null, querySelectorAll: () => [],
    value: '', textContent: '', innerHTML: '', disabled: false,
  });
  const sandbox = {
    console,
    URLSearchParams,
    document: {
      getElementById: () => fakeElement(),
      querySelector: () => fakeElement(),
      querySelectorAll: () => [],
      createElement: () => fakeElement(),
      addEventListener: () => {},
      body: { appendChild() {}, style: {} },
      documentElement: { setAttribute() {}, style: {} },
    },
    localStorage: { getItem: () => null, setItem() {}, removeItem() {} },
    navigator: { language: 'en-US' },
    fetch: async () => { throw new Error('fetch should not be called by pure engine functions'); },
  };
  sandbox.window = sandbox;
  sandbox.window.location = { replace() {}, href: '', pathname: '/', search: '', hash: '' };
  sandbox.window.addEventListener = () => {};

  const context = vm.createContext(sandbox);
  let lastErr = null;
  scripts.forEach((s, i) => {
    try { vm.runInContext(s, context); } catch (e) { lastErr = { index: i, error: e }; }
  });

  // const/function declared at a script's top level never become
  // properties of the global object, per JS spec — true in a real
  // browser too, not just this sandbox. A later script sharing the
  // SAME context can still reference those bindings directly (same
  // top-level lexical scope) and explicitly expose them for retrieval.
  try {
    vm.runInContext('this.__exports = { simulate, monteCarlo, simulateLong, PROFILES, SIM_DAYS };', context);
  } catch (e) {
    lastErr = { index: 'export', error: e };
  }

  if (!context.__exports || typeof context.__exports.simulate === 'undefined') {
    const detail = lastErr ? ` Last script eval error (script ${lastErr.index}): ${lastErr.error.message}` : '';
    throw new Error('Engine failed to load — simulate/monteCarlo/PROFILES not found after eval.' + detail);
  }

  return context.__exports;
}

// ── Cloudflare env/KV mock, for testing the real backend functions ──
function makeMockKV() {
  const store = new Map();
  return {
    _store: store,
    async get(key) { return store.has(key) ? store.get(key) : null; },
    async put(key, value) { store.set(key, value); },
    async list({ prefix = '', cursor, limit = 1000 } = {}) {
      const keys = [...store.keys()].filter(k => k.startsWith(prefix)).map(name => ({ name }));
      return { keys, list_complete: true, cursor: null };
    },
  };
}

// ── D1 mock, for testing the real business-data functions ──
// Scoped honestly to the exact query shapes Block 2 actually uses —
// this is not a general SQL engine, and doesn't pretend to be one.
// If a future block needs a query shape this doesn't recognize, that's
// a real signal to extend this mock deliberately, not silently.
function makeMockD1() {
  const tables = { businesses: [], business_events: [], business_twin: [], decisions: [] };

  function prepare(sql) {
    return {
      _sql: sql,
      _args: [],
      bind(...args) { this._args = args; return this; },
      async run() {
        const insertMatch = this._sql.match(/INSERT (?:OR REPLACE )?INTO (\w+)/i);
        if (insertMatch) {
          const table = insertMatch[1];
          if (table === 'businesses') {
            const [id, owner_email, name, industry, created_at] = this._args;
            tables.businesses.push({ id, owner_email, name, industry, created_at });
          } else if (table === 'business_events') {
            const [id, business_id, type, data, created_at] = this._args;
            tables.business_events.push({ id, business_id, type, data, created_at });
          } else if (table === 'business_twin') {
            const [business_id, snapshot, refreshed_at] = this._args;
            tables.business_twin = tables.business_twin.filter(t => t.business_id !== business_id);
            tables.business_twin.push({ business_id, snapshot, refreshed_at });
          } else if (table === 'decisions') {
            const [id, business_id, decision_label, baseline_projection, modified_projection, expected_outcome, ai_narrative, created_at] = this._args;
            tables.decisions.push({ id, business_id, decision_label, baseline_projection, modified_projection, expected_outcome, ai_narrative, created_at, user_choice: null, choice_note: null, choice_recorded_at: null, actual_revenue: null, actual_profit: null, outcome_recorded_at: null });
          }
          return { success: true };
        }

        if (/UPDATE decisions SET user_choice = \?, choice_note = \?, choice_recorded_at = \? WHERE id = \?/i.test(this._sql)) {
          const [user_choice, choice_note, choice_recorded_at, id] = this._args;
          const row = tables.decisions.find(d => d.id === id);
          if (row) Object.assign(row, { user_choice, choice_note, choice_recorded_at });
          return { success: true };
        }
        if (/UPDATE decisions SET actual_revenue = \?, actual_profit = \?, outcome_recorded_at = \? WHERE id = \?/i.test(this._sql)) {
          const [actual_revenue, actual_profit, outcome_recorded_at, id] = this._args;
          const row = tables.decisions.find(d => d.id === id);
          if (row) Object.assign(row, { actual_revenue, actual_profit, outcome_recorded_at });
          return { success: true };
        }

        throw new Error('Mock D1: unrecognized run() shape: ' + this._sql);
      },
      async first() {
        if (/SELECT id FROM businesses WHERE id = \? AND owner_email = \?/i.test(this._sql)) {
          const [id, owner_email] = this._args;
          return tables.businesses.find(b => b.id === id && b.owner_email === owner_email) || null;
        }
        if (/SELECT id, name, industry FROM businesses WHERE id = \? AND owner_email = \?/i.test(this._sql)) {
          const [id, owner_email] = this._args;
          const b = tables.businesses.find(b => b.id === id && b.owner_email === owner_email);
          return b ? { id: b.id, name: b.name, industry: b.industry } : null;
        }
        if (/SELECT snapshot, refreshed_at FROM business_twin WHERE business_id = \?/i.test(this._sql)) {
          const [business_id] = this._args;
          return tables.business_twin.find(t => t.business_id === business_id) || null;
        }
        if (/SELECT id FROM decisions WHERE id = \? AND business_id = \?/i.test(this._sql)) {
          const [id, business_id] = this._args;
          return tables.decisions.find(d => d.id === id && d.business_id === business_id) || null;
        }
        if (/SELECT id, decision_label, modified_projection, created_at FROM decisions WHERE id = \? AND business_id = \?/i.test(this._sql)) {
          const [id, business_id] = this._args;
          return tables.decisions.find(d => d.id === id && d.business_id === business_id) || null;
        }
        throw new Error('Mock D1: unrecognized first() query shape: ' + this._sql);
      },
      async all() {
        if (/SELECT id, name, industry, created_at FROM businesses WHERE owner_email = \?/i.test(this._sql)) {
          const [owner_email] = this._args;
          const results = tables.businesses.filter(b => b.owner_email === owner_email).sort((a, b) => b.created_at - a.created_at);
          return { results };
        }
        if (/SELECT id, type, data, created_at FROM business_events WHERE business_id = \? AND type = \?/i.test(this._sql)) {
          const [business_id, type] = this._args;
          const results = tables.business_events.filter(e => e.business_id === business_id && e.type === type).sort((a, b) => b.created_at - a.created_at);
          return { results };
        }
        if (/SELECT id, type, data, created_at FROM business_events WHERE business_id = \?/i.test(this._sql)) {
          const [business_id] = this._args;
          const results = tables.business_events.filter(e => e.business_id === business_id).sort((a, b) => b.created_at - a.created_at);
          return { results };
        }
        if (/SELECT data, created_at FROM business_events WHERE business_id = \? AND type = '(\w+)'/i.test(this._sql)) {
          const typeMatch = this._sql.match(/type = '(\w+)'/i);
          const type = typeMatch[1];
          const [business_id] = this._args;
          const results = tables.business_events.filter(e => e.business_id === business_id && e.type === type).sort((a, b) => a.created_at - b.created_at);
          return { results };
        }
        if (/SELECT data FROM business_events WHERE business_id = \? AND type = '(\w+)' AND created_at >= \?/i.test(this._sql)) {
          const typeMatch = this._sql.match(/type = '(\w+)'/i);
          const type = typeMatch[1];
          const [business_id, sinceTimestamp] = this._args;
          const results = tables.business_events.filter(e => e.business_id === business_id && e.type === type && e.created_at >= sinceTimestamp);
          return { results };
        }
        if (/SELECT id, decision_label, expected_outcome, ai_narrative, user_choice, choice_note, actual_revenue, actual_profit, created_at, choice_recorded_at, outcome_recorded_at FROM decisions WHERE business_id = \?/i.test(this._sql)) {
          const [business_id] = this._args;
          const results = tables.decisions.filter(d => d.business_id === business_id).sort((a, b) => b.created_at - a.created_at);
          return { results };
        }
        throw new Error('Mock D1: unrecognized all() query shape: ' + this._sql);
      },
    };
  }

  return { _tables: tables, prepare };
}

// A D1 mock that genuinely throws on every call — for testing that
// error handling actually catches and returns a clean response,
// rather than just asserting a try/catch block exists in the source.
function makeBrokenMockD1() {
  return {
    prepare() {
      return {
        bind() { return this; },
        async run() { throw new Error('Simulated D1 connection failure'); },
        async first() { throw new Error('Simulated D1 connection failure'); },
        async all() { throw new Error('Simulated D1 connection failure'); },
      };
    },
  };
}

module.exports = { test, section, resetPoint, assert, assertEqual, loadEngine, makeMockKV, makeMockD1, makeBrokenMockD1, run: async () => {
  await chain;
  console.log('\n' + '='.repeat(40));
  console.log(`${passed} passed, ${failed} failed`);
  if (failed > 0) {
    console.log('\nFailures:');
    failures.forEach(f => console.log(`  - ${f.name}\n    ${f.err.message}`));
    process.exitCode = 1;
  } else {
    console.log('All tests passed.');
  }
}};
