// functions/api/business/twin.js — INFINICUS v3 (Block 5)
// GET  /api/business/twin?email=...&businessId=...        (fetch-if-stale)
// POST /api/business/twin  { email, businessId }           (force refresh)
// Requires: INFINICUS_DB (D1) binding
//
// Reuses Block 4's dashboard aggregation directly — the Digital Twin is
// NOT a separate computation, it's that same aggregation with a cache
// in front of it. TTL below is a real, adjustable design choice, not a
// standard to verify against: 5 minutes, matching the same interval
// used for this same concept in a prior, parallel effort on this
// project. Change TTL_MS if a different freshness/cost tradeoff is
// wanted — nothing else depends on this specific value.

import { onRequestGet as dashboard } from './summary/dashboard.js';

import { makeRateLimiter, getClientIP } from '../../_shared/rateLimit.js';

const TTL_MS = 5 * 60 * 1000;

// Two separate tiers: GET can hit the cache (cheap) or trigger a real
// refresh if stale — read tier. POST always forces a real refresh,
// bypassing the whole point of caching — stricter, its own tier.
const checkRateGet = makeRateLimiter(60, 60 * 60 * 1000);
const checkRatePost = makeRateLimiter(20, 60 * 60 * 1000);
export const _resetRateLimiterForTesting = () => { checkRateGet._resetForTesting(); checkRatePost._resetForTesting(); };

const CORS = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
  'Access-Control-Allow-Headers': 'Content-Type',
  'Content-Type': 'application/json',
};

export async function onRequestOptions() {
  return new Response(null, { status: 204, headers: CORS });
}

async function refreshTwin(db, email, businessId, request) {
  const dashboardResult = await dashboard({ request, env: { INFINICUS_DB: db } }).then(r => r.json());
  if (!dashboardResult.ok) return dashboardResult; // propagate the real error (e.g. business not found)

  const refreshedAt = Date.now();
  try {
    await db.prepare(
      'INSERT OR REPLACE INTO business_twin (business_id, snapshot, refreshed_at) VALUES (?, ?, ?)'
    ).bind(businessId, JSON.stringify(dashboardResult), refreshedAt).run();
  } catch (e) {
    return { ok: false, error: 'A database error occurred while caching the twin.' };
  }

  return { ok: true, ...dashboardResult, refreshedAt, stale: false };
}

export async function onRequestGet({ request, env }) {
  if (!checkRateGet(getClientIP(request))) {
    return new Response(JSON.stringify({ ok: false, error: 'Rate limit exceeded. Try again later.' }), { status: 429, headers: CORS });
  }
  const url = new URL(request.url);
  const email = (url.searchParams.get('email') || '').trim().toLowerCase();
  const businessId = (url.searchParams.get('businessId') || '').trim();

  if (!email || !businessId) {
    return new Response(JSON.stringify({ ok: false, error: 'email and businessId query params required.' }), { status: 400, headers: CORS });
  }

  const db = env.INFINICUS_DB;
  if (!db) {
    return new Response(JSON.stringify({ ok: false, error: 'Database not configured. Contact support.' }), { status: 500, headers: CORS });
  }

  let business, cached;
  try {
    business = await db.prepare('SELECT id FROM businesses WHERE id = ? AND owner_email = ?').bind(businessId, email).first();
    if (!business) {
      return new Response(JSON.stringify({ ok: false, error: 'Business not found for this account.' }), { status: 404, headers: CORS });
    }
    cached = await db.prepare('SELECT snapshot, refreshed_at FROM business_twin WHERE business_id = ?').bind(businessId).first();
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: 'A database error occurred.' }), { status: 500, headers: CORS });
  }

  const now = Date.now();

  if (cached && (now - cached.refreshed_at) < TTL_MS) {
    const snapshot = JSON.parse(cached.snapshot);
    return new Response(JSON.stringify({ ok: true, ...snapshot, refreshedAt: cached.refreshed_at, stale: false }), { status: 200, headers: CORS });
  }

  // Stale or never-cached — refresh now, reusing Block 4's real aggregation.
  const result = await refreshTwin(db, email, businessId, request);
  const status = result.ok ? 200 : (result.error === 'Business not found for this account.' ? 404 : 500);
  return new Response(JSON.stringify(result), { status, headers: CORS });
}

export async function onRequestPost({ request, env }) {
  if (!checkRatePost(getClientIP(request))) {
    return new Response(JSON.stringify({ ok: false, error: 'Rate limit exceeded. Try again later.' }), { status: 429, headers: CORS });
  }
  let body = {};
  try { body = await request.json(); } catch (e) {}
  const email = (body.email || '').trim().toLowerCase();
  const businessId = (body.businessId || '').trim();

  if (!email || !businessId) {
    return new Response(JSON.stringify({ ok: false, error: 'email and businessId required.' }), { status: 400, headers: CORS });
  }

  const db = env.INFINICUS_DB;
  if (!db) {
    return new Response(JSON.stringify({ ok: false, error: 'Database not configured. Contact support.' }), { status: 500, headers: CORS });
  }

  let business;
  try {
    business = await db.prepare('SELECT id FROM businesses WHERE id = ? AND owner_email = ?').bind(businessId, email).first();
  } catch (e) {
    return new Response(JSON.stringify({ ok: false, error: 'A database error occurred.' }), { status: 500, headers: CORS });
  }
  if (!business) {
    return new Response(JSON.stringify({ ok: false, error: 'Business not found for this account.' }), { status: 404, headers: CORS });
  }

  // Force refresh: bypass the cache entirely regardless of freshness.
  const getUrl = new URL(request.url);
  getUrl.searchParams.set('email', email);
  getUrl.searchParams.set('businessId', businessId);
  const result = await refreshTwin(db, email, businessId, { url: getUrl.toString() });
  const status = result.ok ? 200 : (result.error === 'Business not found for this account.' ? 404 : 500);
  return new Response(JSON.stringify(result), { status, headers: CORS });
}
